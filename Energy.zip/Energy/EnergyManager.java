package Energy;

import java.util.ArrayList;
import java.util.List;

class EnergyManager {
    private List<Component> components;

    public EnergyManager() {
        this.components = new ArrayList<>();
    }

    public void addComponent(Component component) {
        this.components.add(component);
    }

    public void removeComponent(Component component) {
        this.components.remove(component);
    }

    public int calculateTotalCapacity() {
        int totalCapacity = 0;
        for (Component component : this.components) {
            if (component instanceof Battery) {
                totalCapacity += ((Battery) component).getCapacity();
            }
        }
        return totalCapacity;
    }
}
