package Energy;

public class main {
    public static void main(String[] args) {
        // Create components
        Battery battery1 = new Battery(100);
        Battery battery2 = new Battery(150);
        SolarPanel solarPanel1 = new SolarPanel(50);

        // Create energy manager
        EnergyManager energyManager = new EnergyManager();

        // Add components to the manager
        energyManager.addComponent(battery1);
        energyManager.addComponent(battery2);
        energyManager.addComponent(solarPanel1);

        // Calculate total capacity
        int totalCapacity = energyManager.calculateTotalCapacity();
        System.out.println("Total Capacity of Batteries: " + totalCapacity + " kWh");
    }
}
