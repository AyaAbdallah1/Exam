package Energy;

abstract class Component {
    public abstract String getDetails();
}

class Battery extends Component {
    private int capacity;

    public Battery(int capacity) {
        this.capacity = capacity;
    }

    @Override
    public String getDetails() {
        return "Battery - Capacity: " + this.capacity + " kWh";
    }

    public int getCapacity() {
        return this.capacity;
    }
}
class SolarPanel extends Component {
    private int power;

    public SolarPanel(int power) {
        this.power = power;
    }

    @Override
    public String getDetails() {
        return "Solar Panel - Power Generation: " + this.power + " kW";
    }

    public int generatePower() {
        // Simulate power generation
        return this.power * 5; // Example simulation
    }
}

